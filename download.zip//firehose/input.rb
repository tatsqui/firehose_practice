# Lesson 19 in Firehose Intro Course

puts "Enter your name:"
name = gets.chomp

puts "Enter something you own:"
own = gets.chomp

greeting = "Hello #{name}. What an excellent #{own} you have!"

puts greeting