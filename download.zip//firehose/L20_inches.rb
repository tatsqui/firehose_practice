# Lesson 20 math & numbers 
# Methods, interpolation, concatenation, floats, integers, strings
#------------------------------------------


puts "What is your height (in inches)?"
    height = gets.chomp.to_f

    cm = height.to_f * 2.54

puts "Your height in centimeters is #{cm}cm."
