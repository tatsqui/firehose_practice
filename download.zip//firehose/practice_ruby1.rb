# This is the first practice problem, aka "Homework"
# for lesson 18 on the Firehose Intro Course

puts "##########################"
puts "#  Coded by Tatiana FQ   #"
puts "# I am a coding machine! #"
puts "##########################"