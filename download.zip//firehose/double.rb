def double(num)
   num*2
end

val = double(10)

puts val