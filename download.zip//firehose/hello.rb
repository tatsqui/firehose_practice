# hello.rb, written by Tatiana
# This program follows instructions from the
# Firehose intro course at the Firehose Project.
# ----------------------------------------------


puts "Today I wrote code"
puts "and I am a coding machine..."